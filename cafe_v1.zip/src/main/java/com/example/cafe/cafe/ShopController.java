package com.example.cafe.cafe;

public class ShopController {
    public void setUserId(int userId, String userRole) {
    }
}
